"use client"

import { useState } from "react"
import Header from "./components/Header"
import ChatInterface from "./components/ChatInterface"
import Footer from "./components/Footer"

export default function Home() {
  const [messages, setMessages] = useState<Array<{ sender: string; text: string }>>([])

  const handleSendMessage = (message: string) => {
    setMessages([...messages, { sender: "user", text: message }])
    // Simulate Thom's response (replace this with actual backend call)
    setTimeout(() => {
      setMessages((prev) => [...prev, { sender: "thom", text: getThomResponse(message) }])
    }, 1000)
  }

  // Simple rule-based responses (replace with actual backend logic)
  const getThomResponse = (message: string) => {
    const lowerMessage = message.toLowerCase()
    if (lowerMessage.includes("hello") || lowerMessage.includes("hi")) {
      return "Hey there! Ready for some witty banter?"
    } else if (lowerMessage.includes("how are you")) {
      return "I'm as good as a virtual entity can be. How about you, flesh-based friend?"
    } else {
      return "Well, that's an interesting thought. Let me ponder it while I pretend to have deep AI capabilities."
    }
  }

  return (
    <div className="flex flex-col min-h-screen bg-black text-white">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <ChatInterface messages={messages} onSendMessage={handleSendMessage} />
      </main>
      <Footer />
    </div>
  )
}

