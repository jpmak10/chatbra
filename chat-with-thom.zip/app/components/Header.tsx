import Link from "next/link"
import Image from "next/image"

export default function Header() {
  return (
    <header className="bg-black text-white p-4">
      <div className="container mx-auto">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full overflow-hidden bg-black">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/photo_2025-02-07_00-38-13.jpg-EOGR9IXMDJUt4gskC1sb3qS4LnYCuI.jpeg"
                alt="Bera logo"
                width={48}
                height={48}
                className="object-cover"
                priority
              />
            </div>
            <Link href="/" className="text-2xl font-bold text-brown-500" style={{ fontFamily: "Courier, monospace" }}>
              Chat with Bera
            </Link>
          </div>
          <nav>
            <Link href="https://x.com/BeraChat61737" className="hover:text-brown-500 transition-colors">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M4 4l11.733 16h4.267l-11.733 -16z"></path>
                <path d="M4 20l6.768 -6.768m2.46 -2.46l6.772 -6.772"></path>
              </svg>
            </Link>
          </nav>
        </div>
      </div>
    </header>
  )
}

