"use client"

import { useState } from "react"
import { Send } from "lucide-react"

interface Message {
  sender: string
  text: string
}

interface ChatInterfaceProps {
  messages: Message[]
  onSendMessage: (message: string) => void
}

export default function ChatInterface({ messages, onSendMessage }: ChatInterfaceProps) {
  const [input, setInput] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim()) {
      onSendMessage(input.trim())
      setInput("")
    }
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-gray-900 rounded-lg p-4 mb-4 h-96 overflow-y-auto">
        {messages.map((message, index) => (
          <div key={index} className={`mb-4 ${message.sender === "user" ? "text-right" : "text-left"}`}>
            <div
              className={`inline-block p-3 rounded-lg ${
                message.sender === "user" ? "bg-black text-white" : "bg-brown-500 text-black"
              }`}
            >
              {message.text}
            </div>
          </div>
        ))}
      </div>
      <form onSubmit={handleSubmit} className="flex">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask me anything..."
          className="flex-grow bg-gray-800 text-white rounded-l-lg px-4 py-2 focus:outline-none"
        />
        <button
          type="submit"
          className="bg-brown-500 text-black rounded-r-lg px-4 py-2 hover:bg-brown-600 transition-colors"
        >
          <Send size={24} />
        </button>
      </form>
      <p className="text-sm text-gray-500 mt-2">
        ➝ Only Thom is responsible for what he says, trust him wisely—he jokes a lot, but he stays real.
      </p>
    </div>
  )
}

