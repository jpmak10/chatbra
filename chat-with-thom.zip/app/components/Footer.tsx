import Link from "next/link"
import { ShoppingCart } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">About Us</h3>
            <ul>
              <li>
                <Link href="https://x.com/BeraChat61737" className="hover:text-white!important transition-colors">
                  X (Twitter)
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Utilities</h3>
            <ul>
              <li>
                <Link href="/" className="hover:text-white!important transition-colors">
                  Chat with Bera
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Buy</h3>
            <Link
              href="https://dexscreener.com/moonshot/berachain"
              className="flex items-center hover:text-white!important transition-colors"
            >
              <ShoppingCart className="mr-2" />
              Dexscreener
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

